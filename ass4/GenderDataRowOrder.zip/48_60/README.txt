EigenVectors_xx: eigenvectors of training images for fold xx
EigenValues_xx:  eigenvalues of training images for fold xx

trPCA_xx: 	PCA projected training images for fold xx
TtrPCA_xx: labels of projected training images for fold xx

valPCA_xx: PCA projected validation images for fold xx
TvalPCA_xx: labels of projected validation images for fold xx

tsPCA_xx: PCA projected test images for fold xx
TtsPCA_xx: labels of projected test images for fold xx

